PhantomJS Runner
================

A runner for PhantomJS, providing console output for tests.

Usage:

	phantomjs runner.js url

Example:

	phantomjs runner.js http://localhost/qunit/test

If you're using Grunt, you should take a look at its [qunit task](https://github.com/cowboy/grunt/blob/master/docs/task_qunit.md).