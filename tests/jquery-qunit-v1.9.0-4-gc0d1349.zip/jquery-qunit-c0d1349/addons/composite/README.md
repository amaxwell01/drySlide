Composite - A QUnit Addon For Running Multiple Test Files
================================

Composite is a QUnit addon that, when handed an array of files, will
open each of those files inside of an iframe, run the tests and
display the results as a single suite of QUnit tests.

The Rerun link next to each suite allows you to quickly rerun that suite,
outside the composite runner.

If you want to see what assertion failed in a long list of assertions,
just use the regular "Hide passed tests" checkbox.